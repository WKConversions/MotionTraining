# Validated findings

No experimental findings yet.

- Round 1: For the tested displacement and 24-frame timing, changing curve from 'linear' to 'quintic' reduced decoded centroid and trajectory jerk by at least the configured threshold in three original scenes. Apply this technical default within the tested parameter family; aesthetics and other timings remain unverified.

- Round 15: For original synthesized impacts, changing sfx_offset_frames from 5 to 0 placed the decoded effect-stem peak within one frame of the planned visual event in the primary and two transfer scenes. Mixed MP4 audio was decoded. Perceptual audibility and taste remain unverified.

# Rejected hypotheses

- Round 2: A longer travel interval reduces discrete jerk while retaining at least 24 hold frames. — Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated

- Round 3: Staggering reduces peak simultaneous pixel change without degrading motion continuity. — Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated

- Round 4: A bounded transient can add follow-through without degrading endpoint continuity. — Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated

- Round 5: An alternate curve transfers across changing silhouettes and text frames. — Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated

- Round 6: Shorter or longer motion can balance continuity against readable hold. — Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated

- Round 7: Endpoint derivative continuity reduces encoded centroid jerk at fixed timing. — Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated

- Round 8: A longer travel interval reduces discrete jerk while retaining at least 24 hold frames. — Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated

- Round 9: Staggering reduces peak simultaneous pixel change without degrading motion continuity. — Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated

- Round 10: A bounded transient can add follow-through without degrading endpoint continuity. — Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated

- Round 11: An alternate curve transfers across changing silhouettes and text frames. — Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated

- Round 12: Shorter or longer motion can balance continuity against readable hold. — Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated

- Round 13: Endpoint derivative continuity reduces encoded centroid jerk at fixed timing. — Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated

- Round 18: Test smoother endpoint behavior under the original motion identity — Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated

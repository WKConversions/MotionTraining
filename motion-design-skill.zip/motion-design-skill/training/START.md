# Run the research tooling

The library and SKILL.md are usable as the supplied senior skill. The training/project/
folder preserves the exact research implementation and pinned Python requirements.
The full GitHub project supplies operating documentation and source-control history.
When using the exported tooling separately, retain the downloaded verified skill ZIP,
copy it to training/project/runtime/motion-design-skill.zip along with its SHA256 sidecar,
then run python -m motionlab verify before python -m motionlab resume --continuous.
Processes do not survive snapshots. Study both video and audio and keep subjective
findings experimental without independent evidence. Do not fetch reference videos.

# Autonomous research profile

The user's current request authorizes continuous original experiments across the supplied
skill's capabilities. Preserve SKILL.md and library/ verbatim. The ordinary client-film
approval workflow remains in the original skill; this research profile uses synthetic briefs,
procedural assets, original synthesized music/effects, and local draft speech.
Do not fetch or imitate reference videos. Existing historical reference material is preserved,
not used as visual examples. Never publish the separate private library artifact automatically.
Cycle through motion, timing, transitions, visuals, typography, materials, originality,
rendering libraries, music, sound effects, voice-over and sound-picture synchronization.
Analyze encoded video and decoded audio. Validate transferable technical gains, and keep
subjective findings experimental without a capable independent evaluator. Do not call local
robotic draft speech a professional voice-over. Record gaps and propose future hypotheses.
Every completed round rebuilds the full ZIP, including the original 105 files. Never replace
approved library modules with an unverified preference. Store validated additions in knowledge/
and techniques/ with evidence. Every next round loads the newest verified ZIP.

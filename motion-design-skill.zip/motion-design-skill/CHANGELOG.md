# Changelog

- Initial original renderer and guarded experiment protocol.

- Round 1: validated; Both rendered-video and trajectory jerk improved on primary and two held-out scenes.

- Round 2: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 3: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 4: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 5: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 6: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 7: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 8: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 9: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 10: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 11: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 12: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 13: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 14: imported; Imported senior-motion-designer with 105 byte-preserved files.

- Round 15: validated; Synthesized-effect timing improved on primary and two held-out scenes; mixed audio decoded successfully.

- Round 16: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 17: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 18: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 19: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 20: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 21: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 22: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 23: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 24: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 25: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 26: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 27: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 28: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 29: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 30: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 31: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 32: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 33: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 34: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 35: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 36: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 37: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 38: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 39: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 40: experimental; Primary gain did not transfer to both held-out scenes.

- Round 41: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 42: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 43: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 44: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 45: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 46: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 47: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 48: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 49: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 50: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 51: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 52: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 53: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 54: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 55: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 56: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 57: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 58: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 59: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 60: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 61: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 62: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 63: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 64: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 65: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 66: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 67: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 68: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 69: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 70: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 71: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 72: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 73: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 74: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 75: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 76: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 77: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 78: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 79: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 80: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 81: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 82: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 83: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 84: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 85: experimental; Primary gain did not transfer to both held-out scenes.

- Round 86: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 87: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 88: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 89: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 90: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 91: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 92: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 93: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 94: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 95: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 96: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 97: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 98: experimental; Primary gain did not transfer to both held-out scenes.

- Round 99: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 100: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 101: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 102: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 103: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 104: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 105: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 106: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 107: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 108: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 109: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 110: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 111: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 112: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 113: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 114: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 115: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 116: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 117: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 118: experimental; Primary gain did not transfer to both held-out scenes.

- Round 119: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 120: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 121: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 122: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 123: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 124: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 125: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 126: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 127: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 128: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 129: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 130: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 131: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 132: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 133: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 134: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 135: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 136: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 137: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 138: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

- Round 139: experimental; Rendered and technically checked; subjective comparison awaits a capable independent evaluator.

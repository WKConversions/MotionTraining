# Procedural Animation

Use deterministic seeds, bounded frame-indexed functions and reproducible parameters.

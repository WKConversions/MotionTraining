# Typography

General foundation: readable text requires visual review. Renderer bounds checks establish viewport fit only.

# Composition

General foundation: keep intended content in frame. Bounds checks do not prove good composition.

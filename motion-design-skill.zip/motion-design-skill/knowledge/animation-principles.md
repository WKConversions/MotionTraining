# Animation Principles

General foundations (not experimental discoveries): purposeful motion, clear hierarchy, legible holds.

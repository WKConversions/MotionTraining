# Motion Timing

Hypotheses: smooth endpoint derivatives may reduce discrete jerk. Validate in encoded video before promotion.

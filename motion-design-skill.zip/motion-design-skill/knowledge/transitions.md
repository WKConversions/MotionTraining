# Transitions

Experimental: reveals and morphs may distort centroid proxies. Test separately.

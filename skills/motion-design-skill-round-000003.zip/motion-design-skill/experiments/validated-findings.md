# Validated findings

No experimental findings yet.

- Round 1: For the tested displacement and 24-frame timing, changing curve from 'linear' to 'quintic' reduced decoded centroid and trajectory jerk by at least the configured threshold in three original scenes. Apply this technical default within the tested parameter family; aesthetics and other timings remain unverified.

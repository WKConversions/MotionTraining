# Rejected hypotheses

- Round 2: A longer travel interval reduces discrete jerk while retaining at least 24 hold frames. — Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated

- Round 3: Staggering reduces peak simultaneous pixel change without degrading motion continuity. — Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated

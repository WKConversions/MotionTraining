---
name: motion-design
description: Generate original procedural three-second animations using experimentally supported techniques.
---

# Motion design through controlled experiments

Use the existing isolated checkout; do not create worktrees unless requested.
Load and verify the newest skill ZIP before selecting an experiment.
Read techniques/defaults.json and knowledge/discoveries.md: accepted parameter rules must
actually influence subsequent animation generation. Preserve original sources and seeds.
Render exactly 90 frames at 30 FPS. Analyze encoded video, not just code.
Create original shapes, typography and layouts. Do not use reference videos or templates.
Keep one-variable comparisons and test transfers across at least two held-out scenes.
Technical proxy improvements do not prove aesthetics. Leave visual judgments unevaluated
without a capable independent visual evaluator. Never invent scores.
Archive all completed rounds including unsuccessful experiments. Never promote findings
on scores alone. Verify the ZIP manifest before replacing it, retain archives, and reload
the verified ZIP on the next round. Preserve permanent, experimental and historical knowledge.
Run a broader technical regression every ten rounds. Do not assume more motion is better.

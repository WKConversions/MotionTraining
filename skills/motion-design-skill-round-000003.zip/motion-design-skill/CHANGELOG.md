# Changelog

- Initial original renderer and guarded experiment protocol.

- Round 1: validated; Both rendered-video and trajectory jerk improved on primary and two held-out scenes.

- Round 2: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.

- Round 3: rejected; Candidates did not meet the technical gain threshold; aesthetic hypothesis remains unevaluated.
